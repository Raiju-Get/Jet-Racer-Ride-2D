﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioInterface : MonoBehaviour
{

    [SerializeField] private AudioSO _audioSo;
    [SerializeField] private AudioManager _audioManager;
    
}
